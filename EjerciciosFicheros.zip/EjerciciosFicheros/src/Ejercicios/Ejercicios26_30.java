package Ejercicios;

import java.util.*;
import java.io.*;

public class Ejercicios26_30 {

	static String ruta = "/home/diurno/eclipse-workspace/EjerciciosFicheros/Ejemplos/";

	public static void main(String[] args) {
			
			Scanner teclado = new Scanner(System.in);

	        System.out.println("Elige un ejercicio (1-5):");
	        int opcion = teclado.nextInt();
	        teclado.nextLine();

	        switch (opcion) {
	        case 1:
	            ejercicio26(teclado);
	            break;
	            
	        case 2:
	            ejercicio27(teclado);
	            break;
	            
	        case 3:
	            ejercicio28(teclado);
	            break;
	            
	        case 4:
	            ejercicio29(teclado);
	            break;
	            
	        case 5:
	            ejercicio30();
	            break;
	            
	        default:
	            System.out.println("Opción no válida. Elige un número del 1 al 5.");
	        }

	        teclado.close();
	    }

	    // Ejercicio 26
	    public static void ejercicio26(Scanner teclado) {
	    }

	    // Ejercicio 27
	    public static void ejercicio27(Scanner teclado) {

	    }

	    // Ejercicio 28
	    public static void ejercicio28(Scanner teclado) {

	    }

	    // Ejercicio 29
	    public static void ejercicio29(Scanner teclado) {

	    }

	    // Ejercicio 30
	    public static void ejercicio30() {

	    }


}

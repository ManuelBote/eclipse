package Ejercicios;

import java.util.Scanner;

public class Ejercicio20 {

	public static void main(String[] args) {

		/*
		 * Realiza un programa que, utilizando ficheros, permita gestionar una lista de
		 * teléfonos sin duplicados. En esta lista se almacenará el número de teléfono y
		 * el nombre de la persona. Se deberá crear la clase Teléfonos y un programa que
		 * permita utilizarla. El fichero se almacenará en la carpeta del proyecto con
		 * el nombre Telefonos.dat. El programa permitirá: 
		 *  Añadir un teléfono, no puede haber repeticiones 
		 *  Mostrar la lista de teléfonos 
		 *  Modificar un teléfono por número de teléfono, solamente se modifica el nombre 
		 *  Borrar un teléfono por número de teléfono
		 */
		
		Scanner teclado = new Scanner(System.in);

	}

}

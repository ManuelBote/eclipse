package Ejercicios;


public class Ejercicio1 {

	public static void main(String[] args) {
		
		//1. Mostrar la ruta absoluta de la carpeta actual.
		
		String ruta = System.getProperty("user.dir");
		
		System.out.println("La ruta absoluta actual es: ");
		System.out.println(ruta);

		
	}

}
